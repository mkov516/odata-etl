print('ETL script placeholder')
